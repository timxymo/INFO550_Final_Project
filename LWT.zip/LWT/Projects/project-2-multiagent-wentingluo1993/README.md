# Project 2 Multi-Agent Search

Welcome to Project 2: Multi-Agent Search!

See the project instructions, here: https://anruv.github.io/project/multiagent/index.html
